import logo from '../src/assets/images/atg.jpg';
import './App.css';
import Visualizer from './components/Visualizer';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
      </header>
      <Visualizer></Visualizer>
    </div>
  );
}

export default App;
