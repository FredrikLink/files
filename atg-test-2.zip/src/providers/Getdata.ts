

export async function getBetType(bettype:string): Promise<any> {
    const response = await fetch(`https://www.atg.se/services/racinginfo/v1/api/products/${bettype}`);
    if (!response.ok) {
        throw new Error(`Failed to fetch bettype data with bettype ${bettype}: ${response.statusText}`);
    }
    const bettypeResult = await response.json();
    return bettypeResult;
}

export async function getGame(id:string): Promise<any> {
    const response = await fetch(`https://www.atg.se/services/racinginfo/v1/api/games/${id}`); 
    if (!response.ok) {
        throw new Error(`Failed to fetch games data with id ${id}: ${response.statusText}`);
    }
    const gameResult = await response.json();
    return gameResult;
}