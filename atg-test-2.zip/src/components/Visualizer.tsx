import React, { useState } from "react";
import { getBetType, getGame } from "../providers/Getdata";
import { format } from "date-fns-tz";
import "../components/Visualizer.css";
import { Race, Horse } from "./IVisualizer";

const Visualizer: React.FC = () => {
  const [selectedItem, setSelectedItem] = useState<any | null>(null);

  const toggleCollapse = (e: React.MouseEvent<HTMLDivElement, MouseEvent>) => {
    const clickedElement = e.currentTarget as HTMLElement;
    const collapsedItem = clickedElement.nextSibling as HTMLDivElement;
    if (
      collapsedItem != null &&
      collapsedItem.className === "collapsed race-horse-detail"
    ) {
      if (collapsedItem instanceof HTMLElement) {
        const currentDisplayStyle =
          window.getComputedStyle(collapsedItem).display;
        collapsedItem.style.display =
          currentDisplayStyle === "none" ? "block" : "none";
        clickedElement.style.textDecoration =
          currentDisplayStyle === "none" ? "underline" : "none";
      }
    }
  };

  const handleSelect = async (pickedValue: string) => {
    const betType = await getBetType(pickedValue);
    const betTypeId1 = betType.results[0].id;

    const horseItems = await getGame(betTypeId1);
    if (horseItems) {
      setSelectedItem(horseItems);
    }
  };

  const renderContent = () => {
    if (selectedItem) {
      const racesList: [] = selectedItem.races;
      let trackName: string = "";
      let timeTrackHeader: string = "";
      let countIndex = 0;
      const content = racesList?.map((race: Race, index: number) => {
        const modifiedIndex = index + 1;
        if (race.track != null && race.track.name != null) {
          trackName = race.track.name;
        }

        const raceHorses = race.starts.map((horse: Horse) => {
          countIndex++;
          return (
            <div
              id={countIndex.toString()}
              key={countIndex}
              className="click-div"
            >
              <div onClick={(e) => {
                e.stopPropagation();
                toggleCollapse(e);
              }}>
                <span className="horse-number">{horse.number}</span>
                <span className="horse-name">{horse.horse.name}</span>
                {" - "}
                <span className="horse-driver-firstname">{horse.driver.firstName}</span>
                <span className="horse-driver-lastname">{horse.driver.lastName}</span>
              </div>
              <div className="collapsed race-horse-detail">
                <div>
                  <div>
                    <span className="horse-trainer-text">Tränare:</span> 
                    <span className="horse-trainer-firstname">{horse.driver.firstName}</span> 
                    <span className="horse-trainer-lastname">{horse.driver.lastName}</span>
                  </div>
                  <div>
                    <span className="horse-father-text">Far:</span> 
                    <span className="horse-father-name">{horse.horse.pedigree.father.name ?? "NoFather"}</span>
                  </div>
                </div>
              </div>
            </div>
          );
        });

        let raceScheduledStartTime = new Date(race.scheduledStartTime);

        if (!isNaN(raceScheduledStartTime.getTime())) {
          //console.log('Valid date:', raceScheduledStartTime);
        } else {
          //console.log('Invalid date');
        }

        const formattedUtcTime = format(raceScheduledStartTime, "HH:mm");
        if (modifiedIndex === 1) {
          timeTrackHeader = formattedUtcTime;
        }

        let raceName = "NoName";
        if (race.name !== undefined || race.name != null) {
          if (race.name.length > 20) {
            raceName = race.name.substring(0, 20) + "..";
          } else {
            raceName = race.name + "..";
          }
        }
        const raceNumber = modifiedIndex;

        return (
          <div key={index}>
            <div className="race-header">
              <span>
                {raceNumber} - {raceName ?? "NoName"} - {formattedUtcTime}
              </span>
            </div>
            {raceHorses}
            <br />
          </div>
        );
      });
      return (
        <div>
          <div className="track-name">
            {trackName} {timeTrackHeader}
          </div>
          <div>{content}</div>
        </div>
      );
    }
  };

  return (
    <div>
      <div id="bet-type">
        <select onChange={(e) => handleSelect(e.target.value)}>
          <option value="">Välj speltyp</option>
          <option value="V75">V75</option>
          <option value="V65">V65</option>
          <option value="V64">V64</option>
        </select>
      </div>
      <div className="main-form">{renderContent()}</div>
    </div>
  );
};

export default Visualizer;
