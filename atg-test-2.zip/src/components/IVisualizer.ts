  export interface Race {
    id: number;
    track: {id:number, name:string};
    scheduledStartTime: string;
    starts:any[];
    number: string;
    name: string;
  }
  
  export interface Horse {
    id: number;
    horse: {name:string,trainer:Trainer,pedigree:Pedigree};
    scheduledStartTime: string;
    starts:HorseStarts[];
    number:string;
    driver:Driver;
  }
  
  export interface Trainer{
    firstName: string;
    lastName:string;
  }
  
  export interface Pedigree{
    father: {name:string}
  }
  
  export interface Driver{
    firstName: string;
    lastName:string;
  }
  
  export interface HorseStarts
  {
    horse: {trainer:Trainer,name:string,pedigree:Pedigree};
    number:string;
    driver:Driver;
  }