import { render, screen } from '@testing-library/react';
import App from './App';

describe('Dropdown rendering', () => {
  test('renders V75 option', () => {
    // Arrange
    render(<App />);
  
    // Act
    const linkElementV75 = screen.getByText(/V75/);
  
    // Assert
    expect(linkElementV75).toBeInTheDocument();
  });

  test('renders V65 option', () => {
    // Arrange
    render(<App />);
  
    // Act
    const linkElementV65 = screen.getByText(/V65/);
  
    // Assert
    expect(linkElementV65).toBeInTheDocument();
  });

  test('renders V64 option', () => {
    // Arrange
    render(<App />);
  
    // Act
    const linkElementV64 = screen.getByText(/V64/);
  
    // Assert
    expect(linkElementV64).toBeInTheDocument();
  });
});
